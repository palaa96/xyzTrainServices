<?php 
session_start();
$_SESSION["PassNo"] = "";
session_destroy();
header("Location: index.php");
?>