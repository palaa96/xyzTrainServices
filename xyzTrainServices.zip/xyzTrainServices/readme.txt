--Version 1

--encountering many errors while making booking and signup page. 
--will add more functions to make code concise, less redundant and easy to read.

--dashboard.php is the page where bookings will take place

--if possible try to create a 'style.css' file. Test the styles on 'login.html'
--don't change the other stuff. if you're done, please send it to my college email

--If you have an idea for a better name other than 'xyzTrainServices', message it to me on WhatsApp.
  

--after fixing the above issues and adding 'style.css' to all the pages, i'll send the final project file to both of you. Since we are required to host the website on the internet and not just localhost, i'll get a domain and send you both the link as well





-- some useful resources:
>> https://www.w3schools.com/
>> https://getbootstrap.com/
>> codewithharry on youtube. he has a Web Dev tutorial playlist where he teavhes HTML, CSS and JavaScript