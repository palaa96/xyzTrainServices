<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "railways";
$conn = mysqli_connect($server,$username,$password,$db);
if(!$conn){
    die("Connection error. ".mysqli_connect_error());
}
?>