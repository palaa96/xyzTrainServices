<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>xyz-login</title>
  </head>
  <body>
  <h1 align="center">Welcome to xyz train services!</h1><br><br>
  <h2 align="center">Please login to continue</h2>
  <form action="<?php ($_SERVER["PHP_SELF"]);?>" method="post">
  <div class="mb-3 col-md-6">
    <label for="exampleInputEmail1" class="form-label">Email address or phone number</label>
    <input type="text" class="form-control" id="emailphno" name="emailphno" aria-describedby="emailHelp">
  </div>
  <div class="mb-3 col-md-6">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  
  <button type="submit" class="btn btn-primary" name="submit">Login</button>
</form>
    <br><br><br>
    <p> Don't have an account? <a  href="signup.php" align="right">Sign up</a></p>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST['submit'])){
  require_once "dbconnect.php";
  require_once "func.php";
  $emailphno = filt_input($_POST["emailphno"]);
  $password = $_POST["password"];
  $sql = "";
  $user_exists = false;
  $row=[];
  if($emailphno && $password){
    $hashpass = hash('sha256', $password);
    if(is_numeric($emailphno)){
      $emailphno = (int)$emailphno;
      $stmt = mysqli_prepare($conn,"SELECT * FROM `passenger` WHERE phone_no=? and pass=?");
      mysqli_stmt_bind_param($stmt, 'is', $emailphno, $hashpass);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);
      if (mysqli_num_rows($result) == 0) {
        echo '<div class="alert alert-danger" role="alert"> Account does not exist </div>';
      }
      else{
        $user_exists = true;
        $row = mysqli_fetch_assoc($result);
        $_SESSION["PassNo"] = $row["Passenger_no"];
      }
      mysqli_stmt_close($stmt);    
    }
    else{
      $emailphno = filter_var($emailphno, FILTER_SANITIZE_EMAIL);
      if(filter_var($emailphno, FILTER_VALIDATE_EMAIL)) {
        $stmt = mysqli_prepare($conn,"SELECT * FROM `passenger` WHERE email=? and pass=?");
        mysqli_stmt_bind_param($stmt, 'ss', $emailphno, $hashpass);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) == 0) {
          echo '<div class="alert alert-danger" role="alert"> Account does not exist </div>';
        }
        else{
          $user_exists = true;
          $row = mysqli_fetch_assoc($result);
          $_SESSION["PassNo"] = $row["Passenger_no"];
        }
        mysqli_stmt_close($stmt);
      } 
      else{
        echo '<div class="alert alert-danger" role="alert">
        Invalid email
      </div>';
      }
    }
  }
  else{
    echo '<div class="alert alert-danger" role="alert">
    Please fill in all fields
  </div>';
    echo "<br>";
  }
  if($user_exists){
    echo '<div class="alert alert-success" role="alert">
          user found.
        </div>';
      $_SESSION["PassNo"] = $row["Passenger_no"];
      header("Location: index.php");
  }
  mysqli_close($conn);
}
  
?>